package com.assignment.network.utils

class Constants {
    companion object {
        const val BASE_URL = "http://www.nactem.ac.uk/"
        const val DICTIONARY = "software/acromine/dictionary.py"
    }
}